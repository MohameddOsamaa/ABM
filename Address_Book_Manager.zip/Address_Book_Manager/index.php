<?php 

    include('add.php');
    include('update.php');

?>

 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Address Book Manager</title>
    <!--CSS-->    
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="css/custom.css">
    <!--Javascript-->    
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap.min.js"></script>          
    
     
</head>

<body>
	<h2 align="center">Simple Address Book Manager</h2>
	

    <form role="form" id="info-form" class="form-inline" method="post" action="add.php">

        <div class="form-group">

            <input type="text" required=""  id="form-name-field" class="form-control"  placeholder="Name" name="name">

            <input type="text" required=""  id="form-address-field" class="form-control"  placeholder="Address" name="address">
            
            <input type="tel" required=""  id="form-phone-field" class="form-control"  placeholder="Phone Number" name="phone">
        </div>
        <button type="submit" name="save" class="btn btn-primary"><i class="glyphicon glyphicon-plus">&nbsp;</i>Add New Address</button>

    </form>

     
    <div id="EditModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            
            <form role="form" id="edit-form"  method="post" action="update.php">

                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Edit Address</h4>
                    </div>

                    <div class="modal-body">
                        
                        <div class="form-group">
                            <input type="text" required=""  id="newname" class="form-control"  placeholder="Name" name="newname">

                            <input type="text" required=""  id="newaddress" class="form-control"  placeholder="Address" name="newaddress">
                            
                            <input type="text" required=""  id="newphone" class="form-control"  placeholder="Phone Number" name="newphone">
                            
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="update" class="btn btn-primary">update</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <input type="hidden" name="row_id" id="row_id"/>
                    </div>
                </div>
            </form>
        </div>   
    </div>


	
	<div class="col-md-8 col-md-offset-2">    
    <table id="data" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Address</th>
                <th>Number</th>
                <th width="25%">Actions</th>
            </tr>
        </thead>
    </table>        
</div>


<script type="text/javascript" language="javascript">


//fetch all data
            var dataTable = $('#data').DataTable({
                "processing": true,
                "serverSide": true,
                "ajax":{
                    url:"getdata.php",
                    type:"POST"
                },
                "columnDefs":[
                   {
                    "targets":[3],
                    "orderable":false,
                   },
                ],
            });

//Edit Address
            // $(document).on('click', '.update', function(){
            //     var row_id = $(this).attr("id");
            //        $.ajax({
            //             url:"update.php",
            //             method:"POST",
            //             data:{row_id:row_id},
            //             success:function(data)
            //             {
            //                  alert(data);
            //                  dataTable.ajax.reload();
            //             }
            //         });
            // });


//delete address
            $(document).on('click', '.delete', function(){
                var row_id = $(this).attr("id");
                if(confirm("Are you sure you want to delete this?"))
                {
                   $.ajax({
                        url:"delete.php",
                        method:"POST",
                        data:{row_id:row_id},
                        success:function(data)
                        {
                             alert(data);
                             dataTable.ajax.reload();
                        }
                   });
                }
                else
                {
                   return false; 
                }
            });
</script>

</body>

</html>