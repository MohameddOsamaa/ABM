<?php 

    include('connect.php');

    if(isset($_POST['save'])){
        $name = $_POST['name'];
        $address  = $_POST['address'];
        $phone = $_POST['phone'];

        $stmt = $connection->prepare("INSERT INTO info (name, address, phone) VALUES (?, ?, ?)");
        $stmt->bindParam(1, $name);
        $stmt->bindParam(2, $address);  
        $stmt->bindParam(3, $phone);
        $stmt->execute();
        header('Location: index.php');
    }

    
    
    $connection = null;
 ?>
