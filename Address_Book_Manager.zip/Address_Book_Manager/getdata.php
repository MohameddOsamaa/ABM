<?php 

	include('connect.php');
 


	$output = array();
  $statement = $connection->prepare("SELECT * FROM info");
  $statement->execute();
  $result = $statement->fetchAll();
  $totalData = $statement->rowCount();

  $totalFilter = $totalData;
  


 //  if(isset($_POST["search"]["value"]))
	// {
	//  $query .= 'WHERE name LIKE "%'.$_POST["search"]["value"].'%" ';
	// }
  foreach($result as $row)
	{

	 $sub_array = array();

	 $sub_array[] = $row["Name"];
	 $sub_array[] = $row["Address"];
	 $sub_array[] = "0" . $row["phone"];
	 $sub_array[] = '<ul style="list-style: none;"> <li>
	 							<button type="button" name="update" id="'.$row["id"].'" class="btn btn-xs btn-primary" data-toggle="modal" data-target="#EditModal"><i class="glyphicon glyphicon-pencil">&nbsp;</i>Edit</button>

	 							<button type="button" name="delete" id="'.$row["id"].'" class="btn btn-danger btn-xs delete"><i class="glyphicon glyphicon-trash">&nbsp;</i>Delete</button></li></ul>';
	 $data[] = $sub_array;
	}

	$output=array(
	    "draw"              =>  intval($_POST["draw"]),
	    "recordsTotal"      =>  $totalData,
	    "recordsFiltered"   =>  $totalFilter,
	    "data"              =>  $data
	);

	echo json_encode($output);
?>