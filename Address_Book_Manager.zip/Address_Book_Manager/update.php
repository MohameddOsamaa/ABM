<?php 
	
	include('connect.php');
    if(isset($_POST["update"]))
    {   

        $id = $_POST['row_id'];
        $newname = $_POST['newname'];
        $newaddress  = $_POST['newaddress'];
        $newphone = $_POST['newphone'];

        $statement = $connection->prepare("UPDATE info SET name = '$newname', Address = '$newaddress', phone = '$newphone'  WHERE id = '$id'");
        
        $result = $statement->execute();
             
        if(!empty($result))
        {
            echo 'Data Updated';
            header('Location: index.php');
        }
        else{
        echo '<script>alert("Update Failed")</script>';
        }
    }

?>




